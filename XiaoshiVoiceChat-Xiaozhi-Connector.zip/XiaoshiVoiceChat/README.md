# Xiaoshi Voice Chat — Android starter with WebSocket chat gateway

This ZIP upgrades the original UI with server settings and a WebSocket text-chat connector:
- Funny/friendly/dramatic/calm personality presets and character themes
- Continuous listening / tap-to-talk / text input
- Browser speech recognition and speech synthesis where supported
- WebSocket URL + optional token fields, connection status, and JSON text send/receive
- GitHub Actions workflow to build an Android debug APK

## Important: Xiaozhi compatibility

The new connector is a **generic WebSocket JSON chat gateway**, not a complete implementation of the official Xiaozhi device protocol. A raw Xiaozhi server endpoint may require device registration, a specific handshake, Opus/audio frames, MQTT/UDP, or other protocol details. Pasting a normal Xiaozhi device WebSocket URL here is **not guaranteed to work**.

The connector sends JSON similar to:
```json
{"type":"text","text":"Hello","message":"Hello","language":"vi","personality":"funny","character":"xiaoshi"}
```

If the gateway needs a token, the app sends `{"type":"auth","token":"...","authorization":"..."}` after the WebSocket opens. It accepts replies as plain text or JSON fields `text`, `reply`, `answer`, `message`, `content`, `data.text`, or `data.reply`. Your gateway may need to translate this to the exact API of your AI server.

**For actual official Xiaozhi server/device-protocol compatibility**, implement the matching handshake and real-time audio protocol or use a maintained native client such as [XiaoXin App](https://github.com/fengin/xiaoxin-app). This starter currently sends recognized text to the gateway; microphone audio is not streamed to Xiaozhi. Speech output is the Android/browser TTS voice unless the gateway returns text and a separate TTS integration is added. An identical Xiaoshi voice cannot be guaranteed.

Security notes:
- Use `wss://` in production.
- A token saved in app settings is stored locally on this device and is not a secure secret vault. Avoid account passwords or long-lived privileged tokens.
- Do not embed provider API keys in the APK. Put them on a server you control.

## Build APK with GitHub Actions
1. Create a GitHub repository and upload all files in this ZIP.
2. Open **Actions** and enable workflows if prompted.
3. Run **Build Android APK** (or push to `main`).
4. Open the workflow run → **Artifacts** → download `xiaoshi-debug-apk`.
5. Extract the artifact ZIP to get the debug `.apk`.

## Local build
Requires Node.js 20+ and Android SDK/Java 17:
```bash
npm install
npm run build
npx cap add android
npx cap sync android
```
