import './style.css';

const $ = (s) => document.querySelector(s);
const state = { listening:false, mode:'continuous', voice:'funny', character:'xiaoshi', language:'vi', recognition:null, socket:null, serverConnected:false, serverUrl:'', serverToken:'', useServer:false, pendingServerReply:false };
const avatarMap = { xiaoshi:'小', anime:'✦', robot:'🤖', cat:'🐱' };
const voiceLabels = { funny:'Hài hước 🤣', friendly:'Bạn thân 😊', dramatic:'Drama 🎭', calm:'Điềm tĩnh 🌿' };
const modeLabels = { continuous:'Trò chuyện liên tục', tap:'Bấm mic để nói', text:'Chỉ nhắn tin' };

$('#app').innerHTML = `
  <main class="shell">
    <header><div class="brand-mark">✦</div><div><h1>Xiaoshi Talk</h1><p>Trò chuyện bằng giọng nói</p></div><button id="settingsBtn" class="icon-btn" aria-label="Cài đặt">⚙</button></header>
    <section class="character-card">
      <div class="orb" id="avatar">小</div><div class="status"><span class="live-dot"></span><span id="statusText">Sẵn sàng tám chuyện!</span></div>
      <h2 id="characterName">Xiaoshi</h2><p id="characterLine">Bạn nói đi, tui nghe nè 😎</p>
    </section>
    <section class="chat" id="chat" aria-live="polite">
      <div class="bubble bot">Ê hê! Hôm nay có drama gì kể tui nghe coi 🤣</div>
    </section>
    <section class="controls">
      <button id="micBtn" class="mic"><span>🎙</span><b id="micLabel">Bắt đầu nói</b></button>
      <button id="stopBtn" class="secondary">■ Dừng</button>
    </section>
    <form id="textForm" class="composer"><input id="messageInput" placeholder="Hoặc nhập tin nhắn..." autocomplete="off"/><button aria-label="Gửi">➤</button></form>
    <section id="settings" class="settings hidden">
      <div class="settings-head"><h2>⚙ Tuỳ chỉnh</h2><button id="closeSettings" class="icon-btn">✕</button></div>
      <label>Giọng / tính cách<select id="voiceSelect">
        <option value="funny">Hài hước 🤣</option><option value="friendly">Bạn thân 😊</option><option value="dramatic">Drama 🎭</option><option value="calm">Điềm tĩnh 🌿</option>
      </select></label>
      <label>Cách trò chuyện<select id="modeSelect">
        <option value="continuous">Liên tục — tự nghe lại</option><option value="tap">Bấm mic mỗi lượt</option><option value="text">Chỉ nhắn tin</option>
      </select></label>
      <label>Nhân vật<select id="characterSelect">
        <option value="xiaoshi">Xiaoshi — tím neon</option><option value="anime">Anime — hồng mộng mơ</option><option value="robot">Robot — xanh công nghệ</option><option value="cat">Mèo — vàng vui nhộn</option>
      </select></label>
      <label>Ngôn ngữ<select id="languageSelect">
        <option value="vi">Tiếng Việt</option><option value="zh-CN">中文（普通话）</option><option value="en-US">English</option>
      </select></label>
      <div class="server-box"><h3>🤖 Kết nối máy chủ AI</h3>
        <label class="toggle-row"><input id="useServer" type="checkbox"> Ưu tiên trả lời từ máy chủ</label>
        <label>WebSocket URL<input id="serverUrl" type="url" placeholder="wss://may-chu-cua-ban/ws" autocomplete="url"></label>
        <label>Token (nếu máy chủ yêu cầu)<input id="serverToken" type="password" placeholder="Không bắt buộc" autocomplete="off"></label>
        <div class="server-actions"><button type="button" id="connectServer" class="secondary">Kết nối / thử lại</button><span id="serverStatus">Chưa kết nối</span></div>
        <p class="hint">Chế độ này dùng WebSocket dạng chat JSON cho gateway tương thích. Máy chủ Xiaozhi chuẩn thường dùng giao thức thiết bị/âm thanh riêng; chỉ nhập URL Xiaozhi không đảm bảo kết nối được. Không nhập mật khẩu tài khoản chính.</p>
      </div>
      <p class="hint">Giọng đọc do máy hoặc máy chủ cung cấp; không đảm bảo giống hệt giọng Xiaoshi. Token lưu trên thiết bị này.</p>
      <button id="saveSettings" class="save">Lưu tuỳ chỉnh</button>
    </section>
    <footer>Voice UI • Nhận giọng nói bằng trình duyệt • Chỉ gửi văn bản đến gateway khi bật kết nối máy chủ</footer>
  </main>`;

const chat = $('#chat');
function addBubble(text, who='bot') {
  const b = document.createElement('div'); b.className = `bubble ${who}`; b.textContent = text; chat.appendChild(b); chat.scrollTop = chat.scrollHeight;
}
function getReply(text) {
  const t = text.toLowerCase();
  if (/xin chào|chào|hello|你好/.test(t)) return state.voice==='funny' ? 'Úi chà, chào người đẹp trai nhất khu phố! Hôm nay có gì vui kể tui nghe 🤣' : 'Chào bạn nè! Hôm nay bạn thế nào?';
  if (/buồn|mệt|chán/.test(t)) return state.voice==='funny' ? 'Ai làm bạn tụt mood vậy? Đưa đây tui phát cho một bài diễn hài chữa lành 😂' : 'Nghe có vẻ hôm nay hơi khó khăn. Kể mình nghe thêm nhé.';
  if (/yêu|thích/.test(t)) return state.voice==='dramatic' ? 'TRỜI ƠI, tình tiết này còn căng hơn phim giờ vàng! Kể tiếp mau! 🎭' : 'Ồ hố, có mùi tình yêu nha! Rồi sao nữa? 😏';
  const replies = {
    funny:['Ủa alo, nghe cuốn nha 🤣 Kể tiếp coi!','Khoan, để tui lấy bắp rang 🍿 Rồi chuyện gì xảy ra?','Tui đang bật chế độ hóng chuyện 300% đây!','Câu này làm CPU của tui muốn đội nón bảo hiểm luôn 😂'],
    friendly:['Mình đang nghe đây, kể tiếp đi 😊','Ừm, rồi bạn cảm thấy thế nào?','Cảm ơn bạn đã kể mình nghe. Nói tiếp nhé!'],
    dramatic:['KHÔNG THỂ TIN ĐƯỢC! Rồi sao nữa?! 🎭','Nhạc nền căng thẳng nổi lên... kể tiếp đi!','Đây đúng là cú plot twist của năm!'],
    calm:['Mình hiểu. Bạn có thể nói thêm nếu muốn.','Mình vẫn đang nghe bạn đây.','Ừ, mình cùng nói chuyện tiếp nhé.']
  };
  const list = replies[state.voice]; return list[Math.floor(Math.random()*list.length)];
}
function speak(text) {
  if (!('speechSynthesis' in window) || state.mode==='text') return;
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = state.language; u.rate = state.voice==='funny' ? 1.12 : state.voice==='calm' ? 0.88 : 1;
  const voices = speechSynthesis.getVoices();
  const match = voices.find(v => v.lang.toLowerCase().startsWith(state.language.toLowerCase().split('-')[0]));
  if (match) u.voice = match;
  speechSynthesis.speak(u);
}
function handleMessage(text) {
  if (!text.trim()) return;
  addBubble(text, 'user');
  if (state.useServer) {
    if (!state.socket || state.socket.readyState !== WebSocket.OPEN) {
      addBubble('Chưa kết nối được máy chủ. Mở Cài đặt → Kết nối máy chủ để kiểm tra URL và cấu hình.', 'bot');
      return;
    }
    state.pendingServerReply = true;
    try {
      state.socket.send(JSON.stringify({ type:'text', text, message:text, language:state.language, personality:state.voice, character:state.character }));
      $('#statusText').textContent = 'Đã gửi tin nhắn đến máy chủ…';
    } catch (err) {
      addBubble('Gửi thất bại: ' + (err?.message || 'lỗi WebSocket'), 'bot');
    }
    return;
  }
  const reply = getReply(text);
  setTimeout(() => { addBubble(reply); speak(reply); }, 350);
}
function setServerStatus(text, connected=false) {
  $('#serverStatus').textContent = text;
  $('#serverStatus').style.color = connected ? '#72f0b1' : '#ffb3b3';
  $('#statusText').textContent = connected ? 'Đã kết nối gateway AI' : text;
}
function disconnectServer() {
  if (state.socket) { try { state.socket.close(); } catch {} }
  state.socket = null; state.serverConnected = false;
}
function connectServer() {
  const url = $('#serverUrl').value.trim();
  const token = $('#serverToken').value.trim();
  if (!url) { setServerStatus('Hãy nhập WebSocket URL (wss://...)'); return; }
  if (!/^wss?:\/\//i.test(url)) { setServerStatus('URL phải bắt đầu bằng ws:// hoặc wss://'); return; }
  disconnectServer(); setServerStatus('Đang kết nối…');
  try {
    const ws = new WebSocket(url);
    state.socket = ws;
    ws.onopen = () => {
      state.serverConnected = true;
      if (token) { try { ws.send(JSON.stringify({ type:'auth', token, authorization:token })); } catch {} }
      setServerStatus('WebSocket đã mở • chờ gateway xác nhận', true);
      addBubble('Đã mở kết nối WebSocket. Nếu máy chủ cần handshake/giao thức riêng, cần gateway chuyển đổi tương ứng.', 'bot');
    };
    ws.onmessage = (event) => {
      let data = event.data;
      if (typeof data !== 'string') { addBubble('Máy chủ trả dữ liệu nhị phân; gateway chat JSON không đọc được định dạng này.', 'bot'); return; }
      try {
        const obj = JSON.parse(data);
        if (obj.type === 'error' || obj.error) { addBubble('Máy chủ: ' + (obj.message || obj.error || 'lỗi không rõ'), 'bot'); return; }
        const reply = obj.text || obj.reply || obj.answer || obj.message || obj.content || obj.data?.text || obj.data?.reply;
        if (typeof reply === 'string' && reply.trim()) { addBubble(reply, 'bot'); speak(reply); state.pendingServerReply=false; $('#statusText').textContent='Sẵn sàng tám chuyện!'; }
        else if (obj.type === 'pong' || obj.type === 'connected' || obj.type === 'auth_ok') setServerStatus('Gateway phản hồi • đã kết nối', true);
      } catch { if (data.trim()) { addBubble(data, 'bot'); speak(data); state.pendingServerReply=false; } }
    };
    ws.onerror = () => setServerStatus('Lỗi WebSocket • kiểm tra URL/CORS/chứng chỉ');
    ws.onclose = (event) => { state.serverConnected=false; if (state.socket === ws) state.socket=null; setServerStatus(`Đã ngắt kết nối (${event.code || 'không mã'})`); };
  } catch (err) { setServerStatus('Không thể kết nối: ' + (err?.message || 'URL không hợp lệ')); }
}
function updateCharacter() {
  $('#avatar').textContent = avatarMap[state.character];
  $('#characterName').textContent = ({xiaoshi:'Xiaoshi',anime:'Mimi',robot:'Robo',cat:'Miu Miu'})[state.character];
  $('#characterLine').textContent = ({xiaoshi:'Bạn nói đi, tui nghe nè 😎',anime:'Nói nhỏ thôi, tim tớ rung rồi ✨',robot:'Hệ thống hóng chuyện đã khởi động.',cat:'Meo~ kể chuyện nghe coi 🐾'})[state.character];
  document.body.dataset.character = state.character;
  $('#micBtn').classList.toggle('active', state.listening);
  $('#micLabel').textContent = state.listening ? 'Đang nghe… chạm để dừng' : 'Bắt đầu nói';
  $('#statusText').textContent = state.listening ? 'Tui đang nghe nè…' : 'Sẵn sàng tám chuyện!';
}
function startListening() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { addBubble('Máy/trình duyệt này chưa hỗ trợ nhận giọng nói. Hãy thử Chrome trên Android hoặc dùng ô nhập tin nhắn.', 'bot'); return; }
  if (state.listening) { stopListening(); return; }
  state.recognition = new SR();
  state.recognition.lang = state.language; state.recognition.continuous = state.mode==='continuous'; state.recognition.interimResults = false;
  state.listening = true; updateCharacter();
  state.recognition.onresult = (e) => { const result=e.results[e.results.length-1][0].transcript; handleMessage(result); };
  state.recognition.onerror = (e) => { $('#statusText').textContent = 'Mic: '+e.error; };
  state.recognition.onend = () => {
    state.listening = false; updateCharacter();
    if (state.mode==='continuous' && state.keepListening) setTimeout(() => { if (!state.listening) startListening(); }, 700);
  };
  state.keepListening = state.mode==='continuous';
  try { state.recognition.start(); } catch { state.listening=false; updateCharacter(); }
}
function stopListening() {
  state.keepListening = false; state.listening = false;
  try { state.recognition?.stop(); } catch {}
  speechSynthesis?.cancel?.(); updateCharacter();
}
$('#micBtn').onclick = () => state.mode==='text' ? addBubble('Bạn đang chọn chế độ chỉ nhắn tin. Đổi chế độ trong Cài đặt để dùng mic.') : startListening();
$('#stopBtn').onclick = stopListening;
$('#textForm').onsubmit = (e) => { e.preventDefault(); handleMessage($('#messageInput').value); $('#messageInput').value=''; };
$('#settingsBtn').onclick = () => $('#settings').classList.remove('hidden');
$('#closeSettings').onclick = () => $('#settings').classList.add('hidden');
$('#saveSettings').onclick = () => {
  state.voice=$('#voiceSelect').value; state.mode=$('#modeSelect').value; state.character=$('#characterSelect').value; state.language=$('#languageSelect').value;
  state.useServer=$('#useServer').checked; state.serverUrl=$('#serverUrl').value.trim(); state.serverToken=$('#serverToken').value.trim();
  try { localStorage.setItem('xiaoshi-server-config', JSON.stringify({useServer:state.useServer, serverUrl:state.serverUrl, serverToken:state.serverToken})); } catch {}
  stopListening(); updateCharacter(); $('#settings').classList.add('hidden');
  addBubble(`Đã chọn: ${voiceLabels[state.voice]} • ${modeLabels[state.mode]} • ${state.language} • ${state.useServer ? 'Ưu tiên máy chủ AI' : 'Trả lời demo cục bộ'}`);
};
$('#connectServer').onclick = connectServer;
try { const saved=JSON.parse(localStorage.getItem('xiaoshi-server-config') || '{}'); $('#useServer').checked=!!saved.useServer; $('#serverUrl').value=saved.serverUrl || ''; $('#serverToken').value=saved.serverToken || ''; state.useServer=!!saved.useServer; state.serverUrl=saved.serverUrl || ''; state.serverToken=saved.serverToken || ''; } catch {}
updateCharacter();
